import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Grid,
  Box,
  CircularProgress,
  Alert,
  TextField,
  Button,
} from '@mui/material';
import { Search as SearchIcon } from '@mui/icons-material';
import BookCard from '../components/BookCard';
import { bookService } from '../services/bookService';

const Search = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchInput, setSearchInput] = useState(query);

  useEffect(() => {
    if (query) {
      performSearch(query);
    }
  }, [query]);

  const performSearch = async (searchQuery) => {
    if (!searchQuery.trim()) {
      setBooks([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const results = await bookService.searchBooks(searchQuery);
      setBooks(results);
    } catch (err) {
      setError('Failed to search books. Please try again later.');
      console.error('Error searching books:', err);
      setBooks([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchInput.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchInput)}`);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
          Search Books
        </Typography>
        
        <Box component="form" onSubmit={handleSearch} sx={{ display: 'flex', gap: 2, mb: 4 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search by title, author, or description..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            sx={{ flexGrow: 1 }}
          />
          <Button
            type="submit"
            variant="contained"
            startIcon={<SearchIcon />}
            size="large"
            disabled={!searchInput.trim()}
          >
            Search
          </Button>
        </Box>

        {query && (
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            {loading ? 'Searching...' : `Found ${books.length} result(s) for "${query}"`}
          </Typography>
        )}
      </Box>

      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
          <CircularProgress />
        </Box>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {!loading && !error && (
        <>
          {books.length > 0 ? (
            <Grid container spacing={4}>
              {books.map((book) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={book.id}>
                  <BookCard book={book} />
                </Grid>
              ))}
            </Grid>
          ) : query ? (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No books found
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Try searching with different keywords
              </Typography>
            </Box>
          ) : (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <Typography variant="body1" color="text.secondary">
                Enter a search term to find books
              </Typography>
            </Box>
          )}
        </>
      )}
    </Container>
  );
};

export default Search;

