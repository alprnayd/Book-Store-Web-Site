import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Box,
  CircularProgress,
  Alert,
} from '@mui/material';
import BookCard from '../components/BookCard';
import { bookService } from '../services/bookService';

const Home = () => {
  const [featuredBooks, setFeaturedBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        setLoading(true);
        setError(null);
        
        console.log('Fetching books...');
        
        // Try to get all books first (more reliable)
        let books = await bookService.getAllBooks();
        console.log('All books response:', books);
        console.log('Books count:', books?.length);
        
        // If we have books, check if any are featured
        if (books && books.length > 0) {
          const featured = books.filter(book => book.featured === true);
          if (featured.length > 0) {
            console.log('Found featured books:', featured.length);
            books = featured;
          } else {
            console.log('No featured books, showing all books');
          }
        } else {
          console.warn('No books returned from API');
        }
        
        setFeaturedBooks(books || []);
        console.log('Final books set:', books);
        
        if (!books || books.length === 0) {
          setError('No books found in database. Please check backend connection.');
        }
      } catch (err) {
        console.error('Error fetching books:', err);
        console.error('Error details:', {
          message: err.message,
          response: err.response?.data,
          status: err.response?.status,
          url: err.config?.url,
          baseURL: err.config?.baseURL
        });
        
        let errorMessage = 'Failed to load books. ';
        if (err.response) {
          errorMessage += `Server error: ${err.response.status}`;
        } else if (err.request) {
          errorMessage += 'Cannot connect to backend. Make sure backend is running on http://localhost:8080';
        } else {
          errorMessage += err.message || 'Unknown error';
        }
        
        setError(errorMessage);
        setFeaturedBooks([]);
      } finally {
        setLoading(false);
      }
    };

    fetchBooks();
  }, []);

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <Container maxWidth="lg" sx={{ py: 5 }}>
        <Box 
          sx={{ 
            mb: 5, 
            textAlign: 'center',
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            borderRadius: 3,
            p: 4,
            color: 'white',
            boxShadow: 3,
          }}
        >
          <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>
            Welcome to BookStore
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.9 }}>
            Discover your next favorite book from our curated collection
          </Typography>
        </Box>

        <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="h4" component="h2" sx={{ fontWeight: 600, color: 'text.primary' }}>
            {featuredBooks.length > 0 && featuredBooks[0]?.featured ? 'Featured Books' : 'All Books'}
          </Typography>
          {!loading && !error && featuredBooks.length > 0 && (
            <Typography variant="body2" color="text.secondary">
              {featuredBooks.length} {featuredBooks.length === 1 ? 'book' : 'books'} available
            </Typography>
          )}
        </Box>

      {loading && (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 10 }}>
          <CircularProgress size={60} thickness={4} />
          <Typography variant="body1" color="text.secondary" sx={{ mt: 3 }}>
            Loading books...
          </Typography>
        </Box>
      )}

      {error && (
        <Alert 
          severity="error" 
          sx={{ 
            mb: 3,
            borderRadius: 2,
            '& .MuiAlert-icon': {
              fontSize: 28,
            },
          }}
        >
          {error}
        </Alert>
      )}

      {!loading && !error && (
        <Grid container spacing={3}>
          {featuredBooks.length > 0 ? (
            featuredBooks.map((book, index) => (
              <Grid item xs={12} sm={6} md={4} lg={3} key={book.id}>
                <Box
                  sx={{
                    animation: `fadeIn 0.5s ease-in ${index * 0.1}s both`,
                    '@keyframes fadeIn': {
                      from: {
                        opacity: 0,
                        transform: 'translateY(20px)',
                      },
                      to: {
                        opacity: 1,
                        transform: 'translateY(0)',
                      },
                    },
                  }}
                >
                  <BookCard book={book} />
                </Box>
              </Grid>
            ))
          ) : (
            <Grid item xs={12}>
              <Box 
                sx={{ 
                  textAlign: 'center', 
                  py: 8,
                  bgcolor: 'background.paper',
                  borderRadius: 2,
                  boxShadow: 1,
                }}
              >
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  No books available
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Please check back later or contact support.
                </Typography>
              </Box>
            </Grid>
          )}
        </Grid>
      )}
      </Container>
    </Box>
  );
};

export default Home;

