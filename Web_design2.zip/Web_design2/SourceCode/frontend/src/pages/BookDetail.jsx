import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Button,
  Grid,
  Paper,
  CircularProgress,
  Alert,
  Chip,
  Divider,
} from '@mui/material';
import { ArrowBack, AddShoppingCart, ImageNotSupported } from '@mui/icons-material';
import { bookService } from '../services/bookService';
import { useCart } from '../context/CartContext';

const BookDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBook = async () => {
      try {
        setLoading(true);
        const bookData = await bookService.getBookById(id);
        setBook(bookData);
        setError(null);
      } catch (err) {
        setError('Failed to load book details. Please try again later.');
        console.error('Error fetching book:', err);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchBook();
    }
  }, [id]);

  const handleAddToCart = () => {
    if (book) {
      addToCart(book);
    }
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  if (error || !book) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Alert severity="error">{error || 'Book not found'}</Alert>
        <Button
          startIcon={<ArrowBack />}
          onClick={() => navigate('/')}
          sx={{ mt: 2 }}
        >
          Back to Home
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Button
        startIcon={<ArrowBack />}
        onClick={() => navigate('/')}
        sx={{ mb: 3 }}
      >
        Back to Home
      </Button>

      <Grid container spacing={4}>
        <Grid item xs={12} md={4}>
          <Paper elevation={3}>
            <Box
              component="img"
              src={book.imageUrl || ''}
              alt={book.title}
              sx={{
                width: '100%',
                height: 'auto',
                display: 'block',
              }}
              onError={(e) => {
                e.target.style.display = 'none';
                const placeholder = e.target.nextSibling;
                if (placeholder) placeholder.style.display = 'flex';
              }}
            />
            <Box
              sx={{
                width: '100%',
                minHeight: '500px',
                display: 'none',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: 'grey.200',
                flexDirection: 'column',
                gap: 2,
              }}
            >
              <ImageNotSupported sx={{ fontSize: 80, color: 'grey.400' }} />
              <Typography variant="h6" color="text.secondary">
                No Image Available
              </Typography>
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Box>
            <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
              {book.title}
            </Typography>
            
            <Typography variant="h5" color="text.secondary" gutterBottom>
              by {book.author}
            </Typography>

            {book.featured && (
              <Chip
                label="Featured"
                color="primary"
                sx={{ mb: 2 }}
              />
            )}

            <Divider sx={{ my: 3 }} />

            <Box sx={{ mb: 3 }}>
              <Typography variant="h4" color="primary" gutterBottom>
                ${book.price?.toFixed(2) || '0.00'}
              </Typography>
              <Typography variant="body1" color={book.stock > 0 ? 'success.main' : 'error.main'}>
                {book.stock > 0 ? `In Stock (${book.stock} available)` : 'Out of Stock'}
              </Typography>
            </Box>

            {book.description && (
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Description
                </Typography>
                <Typography variant="body1" paragraph>
                  {book.description}
                </Typography>
              </Box>
            )}

            {book.isbn && (
              <Box sx={{ mb: 3 }}>
                <Typography variant="body2" color="text.secondary">
                  ISBN: {book.isbn}
                </Typography>
              </Box>
            )}

            <Button
              variant="contained"
              size="large"
              startIcon={<AddShoppingCart />}
              onClick={handleAddToCart}
              disabled={!book.stock || book.stock === 0}
              sx={{ mt: 2 }}
            >
              Add to Cart
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
};

export default BookDetail;

