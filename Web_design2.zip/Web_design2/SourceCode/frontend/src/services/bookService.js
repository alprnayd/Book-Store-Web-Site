import api from '../api/axios';
import { logError } from '../utils/errors';

export const bookService = {
  // Get all books
  getAllBooks: async () => {
    try {
      const response = await api.get('/books');
      return response.data;
    } catch (error) {
      logError(error, 'getAllBooks');
      throw error;
    }
  },

  // Get featured books (for homepage)
  getFeaturedBooks: async () => {
    try {
      const response = await api.get('/books/featured');
      return response.data;
    } catch (error) {
      logError(error, 'getFeaturedBooks');
      throw error;
    }
  },

  // Get book by ID
  getBookById: async (id) => {
    try {
      if (!id) {
        throw new Error('Book ID is required');
      }
      const response = await api.get(`/books/${id}`);
      return response.data;
    } catch (error) {
      logError(error, 'getBookById');
      throw error;
    }
  },

  // Search books
  searchBooks: async (query) => {
    try {
      if (!query || query.trim() === '') {
        return [];
      }
      const response = await api.get(`/books/search?q=${encodeURIComponent(query)}`);
      return response.data;
    } catch (error) {
      logError(error, 'searchBooks');
      throw error;
    }
  },
};

