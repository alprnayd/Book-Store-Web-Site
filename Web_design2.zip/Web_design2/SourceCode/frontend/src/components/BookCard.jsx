import React from 'react';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  CardActions,
  Box,
  Chip,
} from '@mui/material';
import { AddShoppingCart, ImageNotSupported } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const BookCard = ({ book }) => {
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.stopPropagation();
    addToCart(book);
  };

  const handleCardClick = () => {
    navigate(`/book/${book.id}`);
  };

  // Always show image (backend provides default if missing)
  const imageUrl = book.imageUrl || '';

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        cursor: 'pointer',
        transition: 'all 0.3s ease-in-out',
        borderRadius: 2,
        overflow: 'hidden',
        bgcolor: 'background.paper',
        '&:hover': {
          transform: 'translateY(-8px)',
          boxShadow: 8,
        },
      }}
      onClick={handleCardClick}
    >
      <Box sx={{ position: 'relative', overflow: 'hidden' }}>
        <CardMedia
          component="img"
          height="300"
          image={imageUrl}
          alt={book.title}
          sx={{ 
            objectFit: 'cover',
            transition: 'transform 0.3s ease-in-out',
            '&:hover': {
              transform: 'scale(1.05)',
            },
          }}
          onError={(e) => {
            // If image fails to load, show placeholder
            e.target.style.display = 'none';
            const placeholder = e.target.parentElement.querySelector('.image-placeholder');
            if (placeholder) placeholder.style.display = 'flex';
          }}
        />
        <Box
          className="image-placeholder"
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 300,
            display: 'none',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'grey.200',
            flexDirection: 'column',
            gap: 1,
          }}
        >
        <ImageNotSupported sx={{ fontSize: 60, color: 'grey.400' }} />
        <Typography variant="body2" color="text.secondary">
          No Image
        </Typography>
      </Box>
      </Box>
      <CardContent sx={{ flexGrow: 1, p: 2 }}>
        <Typography gutterBottom variant="h6" component="h2" noWrap>
          {book.title}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          {book.author}
        </Typography>
        {book.featured && (
          <Chip
            label="Featured"
            color="primary"
            size="small"
            sx={{ mb: 1 }}
          />
        )}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
          <Typography variant="h6" color="primary" sx={{ fontWeight: 600 }}>
            ${book.price?.toFixed(2) || '0.00'}
          </Typography>
          <Typography 
            variant="body2" 
            color={book.stock > 10 ? 'success.main' : book.stock > 0 ? 'warning.main' : 'error.main'}
            sx={{ fontWeight: 500 }}
          >
            {book.stock > 0 ? `${book.stock} in stock` : 'Out of stock'}
          </Typography>
        </Box>
      </CardContent>
      <CardActions sx={{ p: 2, pt: 0 }}>
        <Button
          size="medium"
          variant="contained"
          startIcon={<AddShoppingCart />}
          onClick={handleAddToCart}
          fullWidth
          disabled={!book.stock || book.stock === 0}
          sx={{
            borderRadius: 1,
            textTransform: 'none',
            fontWeight: 600,
            py: 1.5,
            '&:hover': {
              transform: 'scale(1.02)',
            },
            transition: 'all 0.2s',
          }}
        >
          Add to Cart
        </Button>
      </CardActions>
    </Card>
  );
};

export default BookCard;
