import React from 'react';
import { Box, Container, Typography, Grid, Link, IconButton } from '@mui/material';
import { GitHub } from '@mui/icons-material';

const Footer = () => {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: '#1976d2',
        color: 'white',
        py: 4,
        mt: 'auto',
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              BookStore
            </Typography>
            <Typography variant="body2">
              Your trusted online bookstore for all your reading needs.
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              Quick Links
            </Typography>
            <Typography variant="body2" component="div">
              <Link href="/" color="inherit" underline="hover" sx={{ display: 'block', mb: 1 }}>
                Home
              </Link>
              <Link href="/cart" color="inherit" underline="hover" sx={{ display: 'block' }}>
                Shopping Cart
              </Link>
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              Contact
            </Typography>
            <Typography variant="body2">
              Email: info@bookstore.com
              <br />
              Phone: +90 (XXX) XXX XX XX
            </Typography>
          </Grid>
        </Grid>
        <Box sx={{ mt: 4, pt: 2, borderTop: '1px solid rgba(255,255,255,0.2)' }}>
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="body2" align="center">
              © {new Date().getFullYear()} BookStore. All rights reserved.
            </Typography>
            <IconButton
              component="a"
              href="https://github.com/alprnayd"
              target="_blank"
              rel="noopener noreferrer"
              sx={{ color: 'white', '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' } }}
              aria-label="GitHub"
            >
              <GitHub />
            </IconButton>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default Footer;

