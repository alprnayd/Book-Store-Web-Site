# BookStore Frontend

React-based frontend application for the BookStore e-commerce platform.

## Technologies Used

- **React 18.2.0** - JavaScript library for building user interfaces
- **Material UI 5.14.20** - React component library
- **React Router DOM 6.20.1** - Client-side routing
- **Axios 1.6.2** - HTTP client for API requests

## Project Structure

```
src/
├── api/
│   └── axios.js              # Axios configuration
├── services/
│   └── bookService.js        # Book API service
├── components/
│   ├── Navbar.jsx            # Navigation bar component
│   ├── Footer.jsx             # Footer component
│   └── BookCard.jsx          # Book card component
├── pages/
│   ├── Home.jsx              # Home page with featured books
│   ├── BookDetail.jsx        # Book detail page
│   └── Cart.jsx              # Shopping cart page
├── context/
│   └── CartContext.js        # Shopping cart context
├── utils/
│   └── errors.js             # Error handling utilities
├── App.jsx                    # Main application component
├── main.jsx                   # Application entry point
├── app.css                    # Application styles
└── index.css                  # Global styles
```

## Installation

1. Navigate to the frontend directory:
```bash
cd SourceCode/frontend
```

2. Install dependencies:
```bash
npm install
```

## Running the Application

Start the development server:
```bash
npm start
```

The application will be available at `http://localhost:3000`

## Features

- **Home Page**: Displays featured books fetched from the backend API
- **Book Details**: View detailed information about individual books
- **Shopping Cart**: Add books to cart, update quantities, and view total
- **Search Functionality**: Search for books by title, author, or description
- **Responsive Design**: Material UI components ensure mobile-friendly design
- **State Management**: React Context API for cart state management

## API Integration

The frontend communicates with the Spring Boot backend API running on `http://localhost:8080/api`

## Build for Production

```bash
npm run build
```

This creates an optimized production build in the `build` folder.





