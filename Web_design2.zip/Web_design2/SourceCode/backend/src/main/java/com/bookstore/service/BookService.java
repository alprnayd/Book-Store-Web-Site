package com.bookstore.service;

import com.bookstore.dto.BookDTO;
import com.bookstore.dto.BookRequestDTO;
import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookService {
    
    @Autowired
    private BookRepository bookRepository;

    // Convert Entity to DTO
    private BookDTO convertToDTO(Book book) {
        BookDTO dto = new BookDTO();
        dto.setId(book.getId().longValue());
        dto.setTitle(book.getTitle());
        dto.setAuthor(book.getAuthor());
        dto.setDescription(book.getDescription());
        dto.setPrice(book.getPrice() != null ? book.getPrice() : 0.0);
        dto.setStock(book.getStock() != null ? book.getStock() : 0);
        dto.setIsbn(book.getIsbn());
        dto.setImageUrl(book.getImageUrl());
        dto.setFeatured(book.getFeatured() != null ? book.getFeatured() : false);
        return dto;
    }

    // Convert DTO to Entity
    private Book convertToEntity(BookRequestDTO dto) {
        Book book = new Book();
        book.setTitle(dto.getTitle());
        book.setAuthor(dto.getAuthor());
        book.setDescription(dto.getDescription());
        book.setPrice(dto.getPrice());
        book.setStock(dto.getStock());
        book.setIsbn(dto.getIsbn());
        book.setImageUrl(dto.getImageUrl());
        book.setFeatured(dto.getFeatured() != null ? dto.getFeatured() : false);
        return book;
    }

    public List<BookDTO> getAllBooks() {
        // Test native query with different table names
        try {
            // Try with lowercase
            List<Object[]> nativeResults1 = bookRepository.testDirectQuery();
            System.out.println("Native query (books) found " + nativeResults1.size() + " rows");
            
            // Try with uppercase
            try {
                List<Object[]> nativeResults2 = bookRepository.testDirectQueryUppercase();
                System.out.println("Native query (BOOKS) found " + nativeResults2.size() + " rows");
            } catch (Exception e) {
                System.out.println("Uppercase query failed: " + e.getMessage());
            }
            
            // Try to count all rows
            Long count = bookRepository.countAllBooks();
            System.out.println("Total books count: " + count);
            
            if (!nativeResults1.isEmpty()) {
                System.out.println("First row from native query: " + java.util.Arrays.toString(nativeResults1.get(0)));
            }
        } catch (Exception e) {
            System.out.println("Native query error: " + e.getMessage());
            e.printStackTrace();
        }
        
        List<Book> allBooks = bookRepository.findAll();
        System.out.println("BookService.getAllBooks() - Found " + allBooks.size() + " books in repository");
        if (!allBooks.isEmpty()) {
            System.out.println("First book: " + allBooks.get(0).getTitle());
        } else {
            System.out.println("WARNING: No books found! Check database connection and table name.");
            System.out.println("Database URL should be: jdbc:postgresql://localhost:5432/bookstoredb");
            System.out.println("Table name should be: products");
        }
        return allBooks.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<BookDTO> getFeaturedBooks() {
        return bookRepository.findByFeaturedTrue()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Optional<BookDTO> getBookById(Integer id) {
        return bookRepository.findById(id)
                .map(this::convertToDTO);
    }

    public List<BookDTO> searchBooks(String query) {
        return bookRepository.searchBooks(query)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public BookDTO saveBook(BookRequestDTO bookRequestDTO) {
        Book book = convertToEntity(bookRequestDTO);
        Book savedBook = bookRepository.save(book);
        return convertToDTO(savedBook);
    }

    public Optional<BookDTO> updateBook(Integer id, BookRequestDTO bookRequestDTO) {
        Optional<Book> existingBook = bookRepository.findById(id);
        if (existingBook.isPresent()) {
            Book book = existingBook.get();
            book.setTitle(bookRequestDTO.getTitle());
            book.setAuthor(bookRequestDTO.getAuthor());
            book.setDescription(bookRequestDTO.getDescription());
            book.setPrice(bookRequestDTO.getPrice());
            book.setStock(bookRequestDTO.getStock());
            book.setIsbn(bookRequestDTO.getIsbn());
            book.setImageUrl(bookRequestDTO.getImageUrl());
            if (bookRequestDTO.getFeatured() != null) {
                book.setFeatured(bookRequestDTO.getFeatured());
            }
            Book updatedBook = bookRepository.save(book);
            return Optional.of(convertToDTO(updatedBook));
        }
        return Optional.empty();
    }

    public Optional<BookDTO> updateBookImageUrl(Integer id, String imageUrl) {
        Optional<Book> existingBook = bookRepository.findById(id);
        if (existingBook.isPresent()) {
            Book book = existingBook.get();
            book.setImageUrl(imageUrl);
            Book updatedBook = bookRepository.save(book);
            return Optional.of(convertToDTO(updatedBook));
        }
        return Optional.empty();
    }

    public void deleteBook(Integer id) {
        bookRepository.deleteById(id);
    }
}
