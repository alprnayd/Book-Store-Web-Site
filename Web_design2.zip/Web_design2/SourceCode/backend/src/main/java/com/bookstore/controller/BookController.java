package com.bookstore.controller;

import com.bookstore.dto.BookDTO;
import com.bookstore.dto.BookRequestDTO;
import com.bookstore.dto.ImageUrlUpdateDTO;
import com.bookstore.service.BookService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseEntity<List<BookDTO>> getAllBooks() {
        List<BookDTO> books = bookService.getAllBooks();
        System.out.println("GET /api/books - Found " + books.size() + " books");
        return ResponseEntity.ok(books);
    }

    @GetMapping("/featured")
    public ResponseEntity<List<BookDTO>> getFeaturedBooks() {
        List<BookDTO> books = bookService.getFeaturedBooks();
        return ResponseEntity.ok(books);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable Integer id) {
        Optional<BookDTO> book = bookService.getBookById(id);
        return book.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public ResponseEntity<List<BookDTO>> searchBooks(@RequestParam String q) {
        if (q == null || q.trim().isEmpty()) {
            return ResponseEntity.ok(bookService.getAllBooks());
        }
        List<BookDTO> books = bookService.searchBooks(q);
        return ResponseEntity.ok(books);
    }

    @PostMapping
    public ResponseEntity<BookDTO> createBook(@Valid @RequestBody BookRequestDTO bookRequestDTO) {
        BookDTO savedBook = bookService.saveBook(bookRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBook);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BookDTO> updateBook(@PathVariable Integer id, @Valid @RequestBody BookRequestDTO bookRequestDTO) {
        Optional<BookDTO> updatedBook = bookService.updateBook(id, bookRequestDTO);
        if (updatedBook.isPresent()) {
            return ResponseEntity.ok(updatedBook.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PatchMapping("/{id}/image")
    public ResponseEntity<BookDTO> updateBookImageUrl(@PathVariable Integer id, @RequestBody ImageUrlUpdateDTO imageUrlUpdateDTO) {
        if (imageUrlUpdateDTO.getImageUrl() == null || imageUrlUpdateDTO.getImageUrl().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        Optional<BookDTO> updatedBook = bookService.updateBookImageUrl(id, imageUrlUpdateDTO.getImageUrl());
        if (updatedBook.isPresent()) {
            return ResponseEntity.ok(updatedBook.get());
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Integer id) {
        Optional<BookDTO> book = bookService.getBookById(id);
        if (book.isPresent()) {
            bookService.deleteBook(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
