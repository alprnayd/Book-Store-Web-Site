package com.bookstore.repository;

import com.bookstore.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {
    List<Book> findByFeaturedTrue();
    
    @Query("SELECT b FROM Book b WHERE b.title LIKE %:query% OR b.author LIKE %:query% OR b.description LIKE %:query%")
    List<Book> searchBooks(String query);
    
    // Native query to test direct database access
    @Query(value = "SELECT * FROM products", nativeQuery = true)
    List<Object[]> findAllNative();
    
    // Test with specific columns
    @Query(value = "SELECT id, title, author, description FROM products LIMIT 5", nativeQuery = true)
    List<Object[]> testDirectQuery();
    
    // Test with uppercase table name
    @Query(value = "SELECT id, title, author, description FROM PRODUCTS LIMIT 5", nativeQuery = true)
    List<Object[]> testDirectQueryUppercase();
    
    // Count all books
    @Query(value = "SELECT COUNT(*) FROM products", nativeQuery = true)
    Long countAllBooks();
}

