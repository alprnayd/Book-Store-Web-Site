package com.bookstore.dto;

public class ImageUrlUpdateDTO {
    private String imageUrl;

    public ImageUrlUpdateDTO() {
    }

    public ImageUrlUpdateDTO(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}





