# BookStore Backend

Spring Boot REST API backend for the BookStore e-commerce application.

## Technologies Used

- **Spring Boot 3.2.0** - Java framework for building web applications
- **Spring Data JPA** - Data persistence layer
- **PostgreSQL** - Relational database
- **Maven** - Dependency management and build tool
- **Lombok** - Reduces boilerplate code

## Project Structure

```
src/main/java/com/bookstore/
├── BookstoreApplication.java    # Main application class
├── controller/
│   └── BookController.java      # REST API endpoints
├── model/
│   └── Book.java                 # Book entity
├── repository/
│   └── BookRepository.java       # Data access layer
└── service/
    └── BookService.java          # Business logic layer
```

## Prerequisites

- Java 17 or higher
- Maven 3.6 or higher
- PostgreSQL 12 or higher
- IntelliJ IDEA (recommended)

## Database Setup

1. Create a PostgreSQL database named `bookstore`:
```sql
CREATE DATABASE bookstore;
```

2. Update database credentials in `src/main/resources/application.properties`:
```properties
spring.datasource.username=your_username
spring.datasource.password=your_password
```

3. Run the SQL script from `SourceCode/database/bookstore_schema.sql` to create tables and insert sample data.

## Running the Application

### Using IntelliJ IDEA

1. Open the `SourceCode/backend` folder in IntelliJ IDEA
2. Wait for Maven to download dependencies
3. Run `BookstoreApplication.java` as a Spring Boot application

### Using Maven Command Line

1. Navigate to the backend directory:
```bash
cd SourceCode/backend
```

2. Run the application:
```bash
mvn spring-boot:run
```

The API will be available at `http://localhost:8080`

## API Endpoints

### Books

- `GET /api/books` - Get all books
- `GET /api/books/featured` - Get featured books
- `GET /api/books/{id}` - Get book by ID
- `GET /api/books/search?q={query}` - Search books
- `POST /api/books` - Create a new book
- `PUT /api/books/{id}` - Update a book
- `DELETE /api/books/{id}` - Delete a book

## Configuration

Application configuration is in `src/main/resources/application.properties`:

- Server port: 8080
- Database: PostgreSQL
- JPA: Auto-update schema on startup

## CORS Configuration

The backend is configured to accept requests from `http://localhost:3000` (React frontend).

