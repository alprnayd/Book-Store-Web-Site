-- BookStore Database Schema
-- PostgreSQL Database Export
-- This file contains the complete database structure and sample data

-- Drop existing tables if they exist
DROP TABLE IF EXISTS products CASCADE;

-- Create products table
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    description TEXT,
    price DOUBLE PRECISION,
    stock INTEGER,
    isbn VARCHAR(50),
    image_url VARCHAR(500),
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index on featured column for faster queries
CREATE INDEX idx_products_featured ON products(featured);

-- Create index on title and author for search functionality
CREATE INDEX idx_products_title ON products(title);
CREATE INDEX idx_products_author ON products(author);

-- Insert sample data
INSERT INTO products (title, author, description, price, stock, isbn, image_url, featured) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 'A classic American novel set in the Jazz Age, following the mysterious millionaire Jay Gatsby and his obsession with Daisy Buchanan.', 12.99, 50, '978-0-7432-7356-5', 'https://images-na.ssl-images-amazon.com/images/I/81QuEGw8VPL.jpg', true),
('To Kill a Mockingbird', 'Harper Lee', 'A gripping tale of racial injustice and childhood innocence in the American South, told through the eyes of Scout Finch.', 11.99, 45, '978-0-06-112008-4', 'https://images-na.ssl-images-amazon.com/images/I/81aY1lxllmL.jpg', true),
('1984', 'George Orwell', 'A dystopian social science fiction novel about totalitarian control and surveillance in a future society.', 13.99, 60, '978-0-452-28423-4', 'https://images-na.ssl-images-amazon.com/images/I/81StSOpmkjL.jpg', true),
('Pride and Prejudice', 'Jane Austen', 'A romantic novel of manners that follows the character development of Elizabeth Bennet, the dynamic protagonist.', 10.99, 40, '978-0-14-143951-8', 'https://images-na.ssl-images-amazon.com/images/I/71Q1tPupKjL.jpg', true),
('The Catcher in the Rye', 'J.D. Salinger', 'A controversial novel about teenage rebellion and alienation, told from the perspective of Holden Caulfield.', 9.99, 35, '978-0-316-76948-0', 'https://images-na.ssl-images-amazon.com/images/I/81OthjkJBuL.jpg', false),
('Lord of the Flies', 'William Golding', 'A story about a group of British boys stranded on an uninhabited island and their disastrous attempt to govern themselves.', 8.99, 30, '978-0-571-05686-5', 'https://images-na.ssl-images-amazon.com/images/I/81WUAoL-wFL.jpg', false),
('The Hobbit', 'J.R.R. Tolkien', 'A fantasy novel about the hobbit Bilbo Baggins and his journey to help a group of dwarves reclaim their mountain home.', 14.99, 55, '978-0-544-10295-2', 'https://images-na.ssl-images-amazon.com/images/I/712cDO7d73L.jpg', true),
('Animal Farm', 'George Orwell', 'An allegorical novella about a group of farm animals who rebel against their human farmer.', 7.99, 25, '978-0-452-28424-1', 'https://images-na.ssl-images-amazon.com/images/I/91LUbAcpACL.jpg', false),
('Brave New World', 'Aldous Huxley', 'A dystopian novel set in a futuristic World State where citizens are environmentally engineered into an intelligence-based social hierarchy.', 12.99, 20, '978-0-06-085052-4', 'https://images-na.ssl-images-amazon.com/images/I/81zE42gT3xL.jpg', false),
('The Lord of the Rings', 'J.R.R. Tolkien', 'An epic high fantasy novel about the quest to destroy the One Ring and defeat the Dark Lord Sauron.', 19.99, 70, '978-0-544-10296-9', 'https://images-na.ssl-images-amazon.com/images/I/71jLBXtWJWL.jpg', true),
('Jane Eyre', 'Charlotte Brontë', 'A novel about an orphan girl who becomes a governess and falls in love with her employer, Mr. Rochester.', 11.99, 38, '978-0-14-144114-6', 'https://images-na.ssl-images-amazon.com/images/I/81Y5ZJQZJZL.jpg', false),
('Wuthering Heights', 'Emily Brontë', 'A tale of passion and revenge set in the Yorkshire moors, centered on the relationship between Heathcliff and Catherine.', 10.99, 32, '978-0-14-143955-6', 'https://images-na.ssl-images-amazon.com/images/I/81Y5ZJQZJZL.jpg', false);

-- Create a function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create a trigger to automatically update the updated_at column
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

