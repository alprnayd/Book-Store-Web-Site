# Database Schema

This folder contains the PostgreSQL database schema and sample data for the BookStore application.

## File

- `bookstore_schema.sql` - Complete database structure with tables, indexes, triggers, and sample data

## Database Setup

1. Create the database (database name should match your application.properties):
```sql
CREATE DATABASE bookstoredb;
```

2. Run the schema file:
```bash
psql -U postgres -d bookstoredb -f bookstore_schema.sql
```

Or using psql:
```sql
\c bookstoredb
\i bookstore_schema.sql
```

## Database Structure

### Books Table

| Column | Type | Description |
|--------|------|-------------|
| id | BIGSERIAL | Primary key |
| title | VARCHAR(255) | Book title |
| author | VARCHAR(255) | Book author |
| description | TEXT | Book description |
| price | DOUBLE PRECISION | Book price |
| stock | INTEGER | Available stock |
| isbn | VARCHAR(50) | ISBN number |
| image_url | VARCHAR(500) | Book cover image URL |
| featured | BOOLEAN | Featured book flag |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |

## Sample Data

The schema includes 12 sample books with various genres and authors for testing purposes.

## Note

Make sure the database name in `application.properties` matches the database you create. The current configuration uses `bookstoredb`.
