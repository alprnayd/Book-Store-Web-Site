# BookStore - E-Commerce Web Application

A full-stack e-commerce web application for selling books, built as a final project for Web Design and Programming course.

## Project Overview

BookStore is a modern e-commerce platform that allows users to browse, search, and purchase books online. The application features a responsive React frontend with Material UI components and a Spring Boot REST API backend.

## Technologies

### Frontend
- **React 18.2.0** - JavaScript library for building user interfaces
- **Material UI 5.14.20** - React component library for modern UI design
- **React Router DOM 6.20.1** - Client-side routing
- **Axios 1.6.2** - HTTP client for API communication

### Backend
- **Spring Boot 3.2.0** - Java framework for building REST APIs
- **Spring Data JPA** - Data persistence layer
- **PostgreSQL** - Relational database management system
- **Maven** - Dependency management and build tool

### Database
- **PostgreSQL** - Database server

## Project Structure

```
Web_design2/
├── SourceCode/
│   ├── frontend/          # React frontend application
│   │   ├── src/
│   │   │   ├── api/
│   │   │   ├── services/
│   │   │   ├── components/
│   │   │   ├── pages/
│   │   │   ├── context/
│   │   │   └── utils/
│   │   ├── public/
│   │   └── package.json
│   ├── backend/           # Spring Boot backend application
│   │   ├── src/main/java/com/bookstore/
│   │   │   ├── controller/
│   │   │   ├── model/
│   │   │   ├── repository/
│   │   │   └── service/
│   │   └── pom.xml
│   └── database/          # Database schema and data
│       └── bookstore_schema.sql
└── README.md
```

## Features

1. **Home Page** - Displays featured books fetched from backend API
2. **Book Details** - Detailed view of individual books with descriptions
3. **Shopping Cart** - Add/remove items, update quantities, view totals
4. **Search Functionality** - Search books by title, author, or description
5. **Responsive Design** - Mobile-friendly interface using Material UI
6. **State Management** - React Context API for cart state

## Installation and Setup

### Prerequisites
- Node.js 16+ and npm
- Java 17+
- Maven 3.6+
- PostgreSQL 12+
- IntelliJ IDEA (for backend)

### Database Setup

1. Create PostgreSQL database:
```sql
CREATE DATABASE bookstore;
```

2. Run the SQL script:
```bash
psql -U postgres -d bookstore -f SourceCode/database/bookstore_schema.sql
```

3. Update database credentials in `SourceCode/backend/src/main/resources/application.properties`

### Backend Setup

1. Open `SourceCode/backend` in IntelliJ IDEA
2. Wait for Maven dependencies to download
3. Run `BookstoreApplication.java` as Spring Boot application
4. Backend will run on `http://localhost:8080`

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd SourceCode/frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm start
```

4. Frontend will run on `http://localhost:3000`

## API Endpoints

- `GET /api/books` - Get all books
- `GET /api/books/featured` - Get featured books
- `GET /api/books/{id}` - Get book by ID
- `GET /api/books/search?q={query}` - Search books
- `POST /api/books` - Create new book
- `PUT /api/books/{id}` - Update book
- `DELETE /api/books/{id}` - Delete book

## Project Requirements Compliance

✅ **Research and Learning Effort (20 points)**
- Implemented modern React patterns (Hooks, Context API)
- Used Material UI components effectively
- Applied RESTful API design principles

✅ **Home Page with Backend Integration (20 points)**
- Home page displays featured books
- Data fetched from Spring Boot backend API
- Real-time data loading with error handling

✅ **React Framework Usage (20 points)**
- Component-based architecture
- React Hooks (useState, useEffect, useContext)
- React Router for navigation
- Context API for state management

✅ **Material UI Component Library (20 points)**
- Extensive use of Material UI components
- Custom theming
- Responsive grid system
- Material Design principles

✅ **Web Application Design Principles (20 points)**
- Responsive design
- User-friendly navigation
- Error handling and loading states
- Clean and modern UI/UX

## GitHub Repository

[Add your GitHub repository link here]

## Author

[Your Name]
Student ID: [Your Student ID]

## License

This project is created for educational purposes.

